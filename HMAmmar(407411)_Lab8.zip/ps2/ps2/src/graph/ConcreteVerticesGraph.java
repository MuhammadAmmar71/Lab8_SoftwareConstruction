package graph;

import java.util.*;

public class ConcreteVerticesGraph implements Graph<String> {

    private final List<Vertex> vertices = new ArrayList<>();

    // Abstraction Function:
    // - vertices represents a list of vertices, each with its outgoing edges and weights.

    // Representation Invariant:
    // - Each vertex has a unique label.
    // - Edge weights are positive.

    // Safety from Rep Exposure:
    // - vertices is private and final.
    // - Methods return new collections to prevent external modification.

    private void checkRep() {
        Set<String> labels = new HashSet<>();
        for (Vertex vertex : vertices) {
            assert !labels.contains(vertex.getLabel());
            labels.add(vertex.getLabel());
        }
    }
    
    public static <L> Graph<L> empty() {
        return new ConcreteEdgesGraph<>(); // or new ConcreteVerticesGraph<>()
    }

    @Override
    public boolean add(String vertex) {
        for (Vertex v : vertices) {
            if (v.getLabel().equals(vertex)) {
                return false;
            }
        }
        vertices.add(new Vertex(vertex));
        checkRep();
        return true;
    }
    
    

    @Override
    public int set(String source, String target, int weight) {
        add(source);
        add(target);

        Vertex srcVertex = findVertex(source);
        return srcVertex.setTarget(target, weight);
    }

    @Override
    public boolean remove(String vertex) {
        Vertex toRemove = findVertex(vertex);
        if (toRemove == null) return false;

        vertices.remove(toRemove);
        for (Vertex v : vertices) {
            v.removeTarget(vertex);
        }
        checkRep();
        return true;
    }

    @Override
    public Set<String> vertices() {
        Set<String> labels = new HashSet<>();
        for (Vertex vertex : vertices) {
            labels.add(vertex.getLabel());
        }
        return labels;
    }

    @Override
    public Map<String, Integer> sources(String target) {
        Map<String, Integer> sources = new HashMap<>();
        for (Vertex vertex : vertices) {
            Integer weight = vertex.getTargets().get(target);
            if (weight != null) {
                sources.put(vertex.getLabel(), weight);
            }
        }
        return sources;
    }

    @Override
    public Map<String, Integer> targets(String source) {
        Vertex vertex = findVertex(source);
        if (vertex == null) return new HashMap<>();
        return vertex.getTargets();
    }

    private Vertex findVertex(String label) {
        for (Vertex vertex : vertices) {
            if (vertex.getLabel().equals(label)) return vertex;
        }
        return null;
    }

    @Override
    public String toString() {
        return "Vertices: " + vertices;
    }
}

class Vertex {

    private final String label;
    private final Map<String, Integer> targets = new HashMap<>();

    /**
     * Constructor for Vertex
     * 
     * @param label the label of the vertex
     */
    public Vertex(String label) {
        this.label = label;
        checkRep();
    }

    private void checkRep() {
        for (int weight : targets.values()) {
            assert weight > 0;
        }
    }

    public String getLabel() {
        return label;
    }

    public Map<String, Integer> getTargets() {
        return new HashMap<>(targets);
    }

    public int setTarget(String target, int weight) {
        if (weight == 0) {
            return targets.remove(target) == null ? 0 : weight;
        }
        return targets.put(target, weight) == null ? 0 : weight;
    }

    public void removeTarget(String target) {
        targets.remove(target);
    }

    @Override
    public String toString() {
        return label + " -> " + targets;
    }
}
